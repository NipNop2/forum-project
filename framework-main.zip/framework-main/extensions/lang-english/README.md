# English Language Pack for Flarum

## Installation

This language pack is bundled with [Flarum](http://flarum.org/).

## Translating Flarum

Because Flarum is at an early development stage, instructions to translate it are currently unavailable. 
Please check [our documentation](http://docs.flarum.org) on the topic of translation when it will be written or consult [our community](https://discuss.flarum.org/t/i18n).
