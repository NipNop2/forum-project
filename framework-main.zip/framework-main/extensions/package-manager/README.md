# Package Manager

*An Experiment.*

Read: https://github.com/flarum/package-manager/wiki
