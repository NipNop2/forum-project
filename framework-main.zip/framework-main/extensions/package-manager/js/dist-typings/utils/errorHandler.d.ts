export default function (e: any): void;
