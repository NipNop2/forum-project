export default function tagLabel(tag: any, attrs?: {}): any;
