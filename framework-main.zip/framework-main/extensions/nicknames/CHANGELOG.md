# Changelog

## [1.2.0](https://github.com/flarum/nicknames/compare/v1.1.0...v1.2.0)

### Added
- Prompt for nickname on registration (https://github.com/flarum/nicknames/pull/4).

## [1.1.0](https://github.com/flarum/nicknames/compare/v1.0.0...v1.1.0)

No changes.

## [1.0.0](https://github.com/flarum/nicknames/compare/v0.1.0-beta.16.1...v1.0.0)

### Changed
- Compatibility with Flarum v1.0.0.

## [0.1.0-beta.16.1](https://github.com/flarum/nicknames/compare/v0.1.0-beta.16...v0.1.0-beta.16.1)

- Update for beta 16 search API changes

## [0.1.0-beta.16](https://github.com/flarum/nicknames/compare/v0.1.0-beta.15...v0.1.0-beta.16)

### Changed
- Moved locale files from translation pack to extension (https://github.com/flarum/nicknames/pull/3)

## [0.1.0-beta.15](https://github.com/flarum/nicknames/compare/f139899d706e174128f5e07bcec78ba275181b73...v0.1.0-beta.15)

### Added
- First release.

### Changed
- Updated composer.json and admin javascript for new admin area.

### Fixed
- Usernames can take the value of nicknames (#1)
