# Changelog

## [1.2.0](https://github.com/flarum/akismet/compare/v1.1.0...v1.2.0)

No changes.

## [1.1.0](https://github.com/flarum/akismet/compare/v1.0.0...v1.1.0)

No changes.

## [1.0.0](https://github.com/flarum/bbcode/compare/v0.1.0-beta.16...v1.0.0)

### Changed
- Compatibility with Flarum v1.0.0.

## [0.1.0-beta.16](https://github.com/flarum/bbcode/compare/v0.1.0-beta.15...v0.1.0-beta.16)

### Changed
- Updated admin category from formatting to feature (https://github.com/flarum/bbcode/pull/11)

## [0.1.0-beta.15](https://github.com/flarum/bbcode/compare/v0.1.0-beta.12...v0.1.0-beta.15)

### Changed
- Updated composer.json for new admin area.

## [0.1.0-beta.8](https://github.com/flarum/bbcode/compare/v0.1.0-beta.5...v0.1.0-beta.8)

### Changed
- Update for beta 8
- Drop `flarum-ext-` prefix from package name ([5d47da1](https://github.com/flarum/bbcode/commit/5d47da142a3e340190dc37e461090226dddcf0cd))

## [0.1.0-beta.5](https://github.com/flarum/bbcode/compare/v0.1.0-beta.3...v0.1.0-beta.5)

### Added
- New BBCode tags: DEL, COLOR, CENTER, SIZE (@wackymole)
