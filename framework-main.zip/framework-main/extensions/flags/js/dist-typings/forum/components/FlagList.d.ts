export default class FlagList {
    oninit(vnode: any): void;
    state: any;
    view(): JSX.Element;
}
