export default class FlagsDropdown {
    static initAttrs(attrs: any): void;
    getMenu(): JSX.Element;
    goToRoute(): void;
    getUnreadCount(): any;
    getNewCount(): any;
}
